#ifndef __MAIN__
#define __MAIN__

#include <stdio.h>
#include <stdlib.h>

#define TYPE_SMALL              1
#define TYPE_LARGE              2

#endif